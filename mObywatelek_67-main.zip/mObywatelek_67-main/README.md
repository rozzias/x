Aplikacja nie Generuje Prawdziwych dowodów osobistych i jest wyłącznie przeznaczona do użytku osobistego.
